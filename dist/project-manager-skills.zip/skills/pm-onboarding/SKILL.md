---
name: pm-onboarding
description: >
  Builds a new PM's 30-60-90 day plan from a situation diagnosis: stakeholder map, 1:1
  questions, early wins and a first PRD. Use when starting a PM job, moving to a new
  team, or taking on new scope.
license: MIT + Commons Clause
metadata:
  version: 1.0.1
  author: borghei
  category: project-management
  domain: pm-career
  updated: 2026-11-08
  tech-stack: pm-onboarding, 30-60-90, first-90-days, stars-framework
  tags:
    - pm-onboarding
    - 30-60-90
    - first-90-days
    - new-role
    - pm-career
---
# PM Onboarding Expert

## Overview

A new PM's first 90 days are disproportionately important. Trust earned in the first quarter compounds; missteps in the first quarter haunt for the next year. This skill is a structured 30-60-90 day plan that helps a new PM diagnose the situation, build relationships, identify early wins, and arrive at the end of the quarter with credibility and a clear point of view.

It applies the STARS situation diagnosis (Start-up / Turnaround / Accelerated growth / Realignment / Sustaining success) to set how long to listen before acting.

### The arc in brief

- **Days 1-30 (Learn):** build context; no major decisions, no big PRDs. End with a 1-page "What I'm learning" memo (STARS diagnosis + top-3 going well + top-3 risks).
- **Days 31-60 (Plan):** form a point of view; interview customers yourself; identify 1-2 early wins; align manager + stakeholders. End with a first PRD/strategy memo and draft 6-month roadmap.
- **Days 61-90 (Deliver):** ship the early win; set the operating cadence; write the 90-day retro memo.

Diagnose the STARS situation first — a Sustaining-success area rewards 60+ days of listening; a Turnaround needs decisive action within 30. Misreading the situation is the most common new-PM mistake.

### When to Use

- **New job at a new company** -- use the full 90-day plan from week 1.
- **Internal transfer to a new team** -- compress to 60 days but keep the structure.
- **New scope within the same team** -- use the 30-day learning sprint only.
- **Returning from extended leave (3+ months)** -- use a modified 30-day plan to re-orient.

### When NOT to Use

- First week of a routine role (no major scope change) -- this is overkill.
- Interim leadership (acting role <60 days) -- run a stability-focused playbook instead.

## Quick Start

The workflow, start to finish:

1. Settle the Clarify First inputs; the STARS call and the manager's expectations come first.
2. Fill `assets/30_60_90_plan.md` and `assets/stakeholder_map.md`; run the intro meetings with `assets/onboarding_1on1_questions.md`.
3. Day 30: write the 1-page learning memo. Day 60: first PRD (`assets/first_prd_template.md`) or strategy memo. Day 90: retro memo.
4. Verify that each phase ends with its memo, the manager has confirmed the early win, and every tier-1 stakeholder has had a 1:1 before calling it done. Tactics: `references/30-60-90-plan-and-tactics.md`.

## Clarify First

Before building the onboarding plan, settle the inputs below. When one is missing or vague and would change the result, ask about it; when it wouldn't, use a sensible default and say which one you used.

- **STARS situation:** Start-up, Turnaround, Accelerated-growth, Realignment, or Sustaining-success (sets the listen-vs-act balance; misreading it is the top new-PM mistake).
- **Transition type:** new company, internal transfer, new scope, or return from leave (chooses full-90 vs compressed-60 vs 30-day plan).
- **Manager's 90-day expectations:** what "success" means to them (anchors early-win selection and the whole arc).
- **Scope and key partners:** what the PM owns and who the critical stakeholders are (drives the stakeholder tiers and first-PRD).

Ask about the two or three inputs that matter most for this request, not the whole list. If the user wants a result straight away, produce it and state your assumptions at the top.

## Anti-Patterns

### Stakeholder map with no power dynamics
**Mistake:** The map lists names and titles and stops there.
**Why it happens:** An org chart is easy to copy, and opinions take conversations to learn.
**Instead:** For each stakeholder, record their interest (what they want from your team), their influence and their current sentiment. Use the map to decide who to meet first and who to align before whom.

### Saving the diagnosis for a Day-90 reveal
**Mistake:** You form strong views by Day 30 and keep them private until the 90-day memo.
**Why it happens:** Sharing a half-formed view feels riskier than presenting a finished one.
**Instead:** Share a strawman of your point of view around Day 45-60 and invite input. Before you publish, have at least three stakeholders pressure-test it.

### Overcommitting in the first sprint
**Mistake:** Keen to look productive, you take on eight deliverables in your first sprint and miss five.
**Why it happens:** New PMs want to show value fast, and they don't yet know how long things take here.
**Instead:** Under-promise for the first 60 days. Aim for a 100% hit rate on commitments in the first 30 days. Below 80% damages your reputation for the rest of the year.

Nine more, each with a bad and a good example: `references/red-flags.md`.

## References

Load the reference that matches the task; keep this file lean and pull detail on demand.

- **[references/30-60-90-plan-and-tactics.md](references/30-60-90-plan-and-tactics.md)** — full STARS diagnostic table and diagnosis questions, the week-by-week 30-60-90 plan with outputs, the early-wins playbook, onboarding stakeholder tiers, the first-PRD rules, the run-the-quarter workflow, troubleshooting, and success criteria. Read this when actually building or running the plan.
- **[references/first-90-days-playbook.md](references/first-90-days-playbook.md)** — Watkins-grounded deep dive: the transition trap, STARS in depth, securing early wins, the five-conversations framework, remote/hybrid onboarding, and the 90-day retro memo structure. Read for the underlying theory.
- **[references/red-flags.md](references/red-flags.md)** — bad-vs-good examples of early-tenure decisions. Scan after producing a 30-60-90 plan, stakeholder map, or onboarding artifact.
- `assets/30_60_90_plan.md` — editable 30-60-90 plan template.
- `assets/stakeholder_map.md` — onboarding stakeholder map template.
- `assets/onboarding_1on1_questions.md` — question bank for the first 30 days of 1:1s.
- `assets/first_prd_template.md` — tighter PRD template for new-PM constraints.

External: Watkins, M. *The First 90 Days* (HBR Press, 2013); Bock, L. *Work Rules!* (onboarding at scale).

## Scope & Limitations

**In Scope:** 30-60-90 day plan for new PM roles; STARS situational diagnosis; onboarding stakeholder mapping; first-quarter 1:1 question banks; first-PRD template; early-win identification and execution.

**Out of Scope:** Job-search or offer-evaluation prep (use `personal-productivity/`); compensation negotiation; long-term career planning beyond 90 days (`pm-career-ladder/`); onboarding for non-PM roles.

**Caveats:** The 90-day plan is a planning artifact, not a contract — adjust as you learn. Calibrate "early wins" to the company's pace (a startup's 90-day win may be an enterprise's 180-day win). Your manager's expectations matter most: align in week 1, do not surprise them in week 6.

## Files

| File | Purpose |
|------|---------|
| `assets/30_60_90_plan.md`, `assets/stakeholder_map.md`, `assets/onboarding_1on1_questions.md`, `assets/first_prd_template.md` | Plan, stakeholder tiers, intro questions, first PRD |
| `references/first-90-days-playbook.md`, `references/30-60-90-plan-and-tactics.md`, `references/red-flags.md` | Playbook, phase tactics, failure modes |
| `examples/fintech-series-b-new-pm-30-60-90.md` | Worked plan |

Related skills: `pm-1on1s` after day 90, `senior-pm` (`stakeholder_mapper.py`) for steady-state stakeholder mapping, `execution/create-prd` for the full PRD.
